
function toggleMenu() {
    let sidebar = document.querySelector('.sidebar');
    let overlay = document.querySelector('.overlay');
    
    if (sidebar.style.right === "0px") {
        closeMenu();
    } else {
        sidebar.style.right = "0px";
        overlay.style.opacity = "1";
        overlay.style.visibility = "visible";
    }
}

// تابع برای بستن منو
function closeMenu() {
    let sidebar = document.querySelector('.sidebar');
    let overlay = document.querySelector('.overlay');
    
    sidebar.style.right = "-250px";
    overlay.style.opacity = "0";
    overlay.style.visibility = "hidden";
}