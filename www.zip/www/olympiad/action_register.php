<?php

if 
    (isset($_POST['username']) && !empty($_POST['username']) &&
    isset($_POST['password']) && !empty($_POST['password']) &&
    isset($_POST['repassword']) && !empty($_POST['repassword']) &&
    isset($_POST['email']) && !empty($_POST['email'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $email = $_POST['email'];

    if ($password != $repassword) {
        exit("کلمه عبور با تکرار آن مطابقت ندارد");
    }

    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        exit("آدرس ایمیل وارد شده معتبر نیست");
    }
} else {
    exit("لطفا تمام فیلدها را پر کنید");
}

$link = mysqli_connect("localhost", "root", "", "html");

if (mysqli_connect_errno()) {
    exit("خطای ناشی از شروع دیتابیس: " . mysqli_connect_error());
}

// اصلاح ترتیب مقادیر درج شده در جدول
$query = "INSERT INTO user (username, password, email, type) VALUES ('$username', '$password', '$email', '0')";

if (mysqli_query($link, $query) === true) {
    echo "<p style='color:green;'>عضویت شما با نام کاربری <b>" . $username . "</b> در فروشگاه با موفقیت انجام شد.</p>";
} else {
    echo "<p style='color:red;'>عضویت شما در فروشگاه انجام نشد.</p>";
}

mysqli_close($link);

?>