<?php

// بررسی مقداردهی فیلدهای ورودی
if (isset($_POST['username']) && !empty($_POST['username']) &&
    isset($_POST['password']) && !empty($_POST['password'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

} else {
    exit("پرکردن تمام فیلدها مقدار دهی نشده است!");
}

// اتصال به پایگاه داده
$link = mysqli_connect("localhost", "root", "", "html");

if (mysqli_connect_errno()) {
    exit("خطای ناشی از اتصال به پایگاه داده: " . mysqli_connect_error());
}

// اجرای کوئری برای جستجوی کاربر
$query = "SELECT * FROM user WHERE username='$username' AND password='$password'";
$result = mysqli_query($link, $query);

// بررسی نتیجه کوئری
$row = mysqli_fetch_array($result);

if ($row) {
    echo "<p style='color:green;'> خوش آمدید، <b>" . $username . "</b>! </p>";
} else {
    echo "<p style='color:red;'>نام کاربری یا کلمه عبور شما نادرست است.</p>";
}

// بستن اتصال به پایگاه داده
mysqli_close($link);

?>