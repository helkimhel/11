 <!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>شهرستان امل</title>
    <link rel="stylesheet" href="css/sign.css">
    <script defer src="js/sign.js"></script>
    
<div class="wrapper">
    <div class="title-text">
      <div class="title login">ورود</div>
      <div class="title signup">ثبت نام </div>
    </div>
    <div class="form-container">
      <div class="slide-controls">
        <input type="radio" name="slide" id="login" checked>
        <input type="radio" name="slide" id="signup">
        <label for="login" class="slide login">ورود مجدد</label>
        <label for="signup" class="slide signup">ثبت نام </label>
        <div class="slider-tab"></div>
      </div>
      <div class="form-inner">
        <form action="action_login.php" class="login" method="post">
          <div class="field">
            <input type="text" name="username" placeholder="نام کاربری" required>
          </div>
          <div class="field">
            <input type="password"  name="password" placeholder="گذرواژه" required>
          </div>
          <div class="field">
            <input type="password" name="repassword" placeholder="تکرار گذرواژه" required>
          </div>
          <div class="pass-link"><a href="#">آیا گذرواژه خود را فراموش کرده اید ؟</a></div>
          <div class="field btn">
            <div class="btn-layer"></div>
            <input type="submit" value="ورود ">
          </div>
          <div class="signup-link">یادتان نمی آید ؟ <a href="">الان ثبت نام کنید </a></div>
        </form>
      
        <form action="action_register.php" class="signup" method="post">
        <div class="field">
            <input type="text" name="username"placeholder="نام کاربری " required>
          </div>
          <div class="field">
            <input type="email"name="email" placeholder="آدرس ایمیل" required>
          </div>
          <div class="field">
            <input type="password" name="password" placeholder="گذرواژه" required>
          </div>
          <div class="field">
            <input type="password" name="repassword" placeholder="تکرار گذرواژه" required>
          </div>
          <div class="field btn">
            <div class="btn-layer"></div>
            <input type="submit" value="ثبت نام ">
          </div>
        </form>
      </div>
    </div>
  </div> 

  <!-- <!DOCTYPE HTML>
  <html lang="en">
  <head>
      <meta charset="UTF-8" />
      <title>Google Maps</title>
      <style type="text/css">
        #map-canvas{
          width: 700px;
          height: 500px;
          margin: 0 auto;
        }
      </style>
      <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
      <script type="text/javascript">
         function initialize() {
           var myLatlng = new google.maps.LatLng(36.461038760259825, 52.38497399584031);
           var mapOptions = {
             zoom: 15,
             center: myLatlng,
             mapTypeId: google.maps.TypeId.ROADMAP
           }
            
           var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
            
           var contentString = '<div style="direction: rtl; text-align: right;font-family: Tahoma;">' +
                                       '<h4>Marvdasht , Takhte Jamshid</h4>' +
                                        '<h5>Takhte Jamshid</h5>' +
                                        '</div>';
            
           var infowindow = new google.maps.InfoWindow({
             content: contentString
           });
            
           var marker = new google.maps.Marker({
             position: myLatlng,
             map: map,
             title: 'Takhte Jamshid'
           });
            
           infowindow.open(map, marker);
           google.maps.event.addListener(marker, 'click', function() {
             infowindow.open(map, marker);
           });
         }
      </script>
  </head>
  <body onload="initialize()">
      <div id="map-canvas"></div>
  </body>
  </html> -->