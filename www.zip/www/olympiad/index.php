
<!DOCTYPE html>

<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>شهرستان امل</title>
    <link rel="stylesheet" href="css/style.css">
    
    <script defer src="js/script.js"></script>
    
</head>
<body>
    
    <header>
        <div class="logo-container">
            <img src="img/daria-logo-colored.svg" alt="لوگو" class="logo">
            <h1></h1>
        </div>
        
        <button class="menu-toggle" onclick="toggleMenu()">☰</button>
        <nav id="menu" class="menu">
            <ul>
                <li><a href="index.html">صفحه اصلی</a></li>
                <li><a href="register.php">ثبت نام</a></li>
                <li class="dropdown">
                    <a href="#">خدمات برای شما</a>
                    <ul class="submenu">
                        <li><a href="#">طراحی سایت</a></li>
                        <li><a href="#">برنامه‌نویسی</a></li>
                        <li><a href="#">مشاوره</a></li>
                    </ul>
                </li>
                <li><a href="#">تماس با ما</a></li>
            </ul>
        </nav>
        <div class="search-container">
            <input type="text" placeholder="جستجو...">
            <button class="search-button">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
            </button>
        </div>
        <button class="theme-toggle" onclick="toggleTheme()">🌓</button>
    </header>
    
    <!-- <main> -->  
      <section class="hero">
        <div class="container">
            <div class="content">
                <div class="img"><img src="imag/image/Yellow_Tulips.png" alt=""></div>
                <h2 class="tetx">
                    طراحی سایت <span class="highlight">زهرا رحمانی</span>
                </h2>
            </div>
        </div>
      </section> 
         <div class="container">
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز سفید">
                <div class="text-content">
                    <h3>گل رز سفید</h3>
                    <p>نماد پاکی و صلح</p>
                </div>
            </div>
    
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز قرمز">
                <div class="text-content">
                    <h3>گل رز قرمز</h3>
                    <p>نماد عشق و زیبایی</p>
                </div>
            </div>
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز قرمز">
                <div class="text-content">
                    <h3>گل رز قرمز</h3>
                    <p>نماد عشق و زیبایی</p>
                </div>
            </div>
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز قرمز">
                <div class="text-content">
                    <h3>گل رز قرمز</h3>
                    <p>نماد عشق و زیبایی</p>
                </div>
            </div>
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز صورتی">
                <div class="text-content">
                    <h3>گل رز صورتی</h3>
                    <p>نماد خوشبختی و قدردانی</p>
                </div>
            </div>
    
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز زرد">
                <div class="text-content">
                    <h3>گل رز زرد</h3>
                    <p>نماد دوستی و شادی</p>
                </div>
            </div>
    
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز نارنجی">
                <div class="text-content">
                    <h3>گل رز نارنجی</h3>
                    <p>نماد انرژی و هیجان</p>
                </div>
            </div>
    
            <div class="info-box">
                <img src="img/white_rose.jpg" alt="گل رز بنفش">
                <div class="text-content">
                    <h3>گل رز بنفش</h3>
                    <p>نماد جذابیت و شکوه</p>
                </div>
            </div>
        </div> 
        <br><br><br><br><br>
        
           
         <div class="map-container">
            <iframe 
                id="map" 
                src="https://www.openstreetmap.org/export/embed.html?bbox=51.22,35.6,51.6,35.8&layer=mapnik" 
                width="100%" 
                height="300" 
                allowfullscreen>
            </iframe>
            </div> 
     <footer>
        <div class="container">
            <div class="content">                <div class="about_us">
                    <a class="logo" href="#">
                        <img src="img/daria-logo-colored.svg" alt="لوگو">
                    </a>
                    <p>
                        مقادیر متنوعی از متن در دسترس است، اما اکثر آنها وجود دارند.
                    </p>
                </div>
                    <div class="quick_access">
                    <h6>دسترسی سریع</h6>
                    <ul>
                        <li><a href="#">خانه</a></li>
                        <li><a href="#">خدمات</a></li>
                        <li><a href="#">فروشگاه</a></li>
                        <li><a href="#">وبلاگ</a></li>
                        <li><a href="#">مشتریان</a></li>
                    </ul>
                </div>
    
                <div class="contact">
                    <h6>تماس با ما</h6>
                    <ul>
                        <li class="address">
                            <address>امل اینجا انجا فلانجا </address>
                        </li>
                        <li><span>تماس:</span> <a href="tel:+218500">۰۲۱۸۵۰۰</a></li>
                        <li><span>ایمیل:</span> <a href="mailto:info@example.com">info@example.com</a></li>
                    </ul>
                </div>
    
                <div class="share">
                    <h6>اشتراک ایمیلی</h6>
                    <p>برای آخرین اخبار و به‌روزرسانی‌ها</p>
                    <form class="input_box">
                        <input type="email" placeholder="ایمیل خود را وارد کنید">
                        <button type="submit" class="save">ثبت</button>
                    </form>
                </div>
            </div>
        </div>
    </footer> 
    
</body>
</html>









