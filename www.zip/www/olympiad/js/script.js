let themeClickCount = 0;

// تغییر تم سایت (فقط دو حالت: اصلی و دارک)
function toggleTheme() {
    let body = document.body;
    themeClickCount++;

    if (themeClickCount === 1) {
        body.classList.remove("dark");
        body.classList.add("dark");
        localStorage.setItem("theme", "dark");
    } else {
        body.classList.remove("dark");
        localStorage.removeItem("theme");
        themeClickCount = 0;
    }
}

// نمایش و مخفی کردن منوی همبرگری
function toggleMenu() {
    let menu = document.getElementById("menu");
    menu.classList.toggle("active");
}

// بسته شدن منو با کلیک خارج از آن
document.addEventListener("click", function(event) {
    let menu = document.getElementById("menu");
    let menuButton = document.querySelector(".menu-toggle");

    if (!menu.contains(event.target) && !menuButton.contains(event.target)) {
        menu.classList.remove("active");
    }
    
});

document.getElementById("toggleButton1").addEventListener("click", function () {
    let newsBox = document.getElementById("newsBox1");
    newsBox.classList.toggle("expanded");

    if (newsBox.classList.contains("expanded")) {
        this.textContent = "نمایش کمتر";
    } else {
        this.textContent = "نمایش بیشتر";
    }
});

// برای دکمه دوم
document.getElementById("toggleButton2").addEventListener("click", function () {
    let newsBox = document.getElementById("newsBox2");
    newsBox.classList.toggle("expanded");

    if (newsBox.classList.contains("expanded")) {
        this.textContent = "نمایش کمتر";
    } else {
        this.textContent = "نمایش بیشتر";
    }
});
